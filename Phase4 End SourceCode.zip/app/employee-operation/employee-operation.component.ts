import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee} from '../employee'
import { EmployeeService } from '../employee.service';
import {FormGroup,FormControl} from '@angular/forms';

@Component({
  selector: 'app-employee-operation',
  templateUrl: './employee-operation.component.html',
  styleUrls: ['./employee-operation.component.css']
})
export class EmployeeOperationComponent implements OnInit {
  

  employee:any;
  constructor(public router:Router,public ps:EmployeeService) { }


  ngOnInit(): void {
    let obj = sessionStorage.getItem("employeeInfo");
    if(obj != null){
        this.employee= JSON.parse(obj);
    }
  }


  ViewAll(){
    this.router.navigate(["employee"]);
}

deleteEmployee(id:any){
    this.ps.delete(id).subscribe({
      next:(result:any)=>console.log(result),
      error:(error:any)=>console.log(error),
      complete:()=>console.log("completed")
    })
}





}


